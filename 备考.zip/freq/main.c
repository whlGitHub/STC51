#include<STC15F2K60S2.H>
#include <intrins.h>
#include<stdio.h>
#define uchar unsigned char
#define uint unsigned int
void delayMs(int ms);
void allInit();
char readKbd();
void ds(char com,char num);
void Timer1Init(void) ;
void Timer0Init(void) ;
void smg_xianshi(uchar yi,er,san,si,wu,liu,qi,ba);

unsigned char code ledStatus[]={0XFF,0XFE,0XFD,0XFB,0XF7,0XEF,0XDF,0XBF,0X7F,0X00};
unsigned char code dscom[]={0X00,0X01,0X02,0X04,0X08,0X10,0X20,0X40,0X80,0XFF};//位选
unsigned char code dsnum[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf,0xff};//字符
uchar code  tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf,0xff};
unsigned int freq,tt;
void SendStr(unsigned char *ptr);
char putchar(char c);
void UartInit();
void main()
{

	unsigned char d1,d2,d3,d4,d5;
	allInit();
	Timer0Init() ;
	Timer1Init() ;
	UartInit();
	EA = 1;
	ET1 = 1;
	while(1)
	{
		printf("Frenquence: %d\r\n",freq);
		d1 = freq/10000;d2 = (freq%10000)/1000;
		d3 = (freq%1000)/100;d4= (freq%100)/10;
		d5 = (freq%100)%10;
		ds(1,d1);
		ds(2,d2);
		ds(3,d3);
		ds(4,d4);
		ds(5,d5);
		//smg_xianshi(d1,d2,d3,d4,d5,11,11,11);
	}
	
}
void ds(char com,char num)
{
	P2=0XC0;
	P0=dscom[com];
	P2=0XE0;
	P0=dsnum[num];
	P2=0xFF;
	delayMs(5);
}

 
void delay(uint x)
{
uchar i;
		while(x--)
		{
			for(i=0;i<120;i++);
		}

}

void allInit()
{
	P2=0XA0;
	P0=0X00;

	P2=0X80;
	P0=0XFF;

	P2=0XC0;
	P0=0XFF;
	P2=0XE0;
	P0=0XFF;
}



void delayMs(int ms)
{
	int i,j;
	for(i=ms;i>0;i--)
		for(j=845;j>0;j--);
}





sbit r1=P3^0;    //4行
sbit r2=P3^1;
sbit r3=P3^2;
sbit r4=P3^3;
                 //4列
sbit c1=P4^4;
sbit c2=P4^2;
sbit c3=P3^5;
sbit c4=P3^4;
char readKbd(void)
{
	unsigned char key_value = 0;

	r1=0;
	r2=r3=r4=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=1;
	else if(!c2) key_value=2;
	else if(!c3) key_value=3;
	else if(!c4) key_value=4;

    r2=0;
	r1=r3=r4=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=5;
	else if(!c2) key_value=6;
	else if(!c3) key_value=7;
	else if(!c4) key_value=8;

	r3=0;
	r2=r1=r4=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=9;
	else if(!c2) key_value=10;
	else if(!c3) key_value=11;
	else if(!c4) key_value=12;

	r4=0;
	r2=r3=r1=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=13;
	else if(!c2) key_value=14;
	else if(!c3) key_value=15;
	else if(!c4) key_value=16;
	
	return key_value;
}

void timer1()        interrupt 3
{
	tt++;
	if(tt==1000)
	{
			TR0=0;        
			tt=0;
			freq=TH0*256+TL0;
			TH0=0;
			TL0=0;
			TR0=1;
	}        
}

void Timer1Init(void)		//1毫秒@11.0592MHz
{
	AUXR |= 0x40;		//定时器时钟1T模式
	TMOD &= 0x0F;		//设置定时器模式
	TL1 = 0xCD;		//设置定时初值
	TH1 = 0xD4;		//设置定时初值
	TF1 = 0;		//清除TF1标志
	TR1 = 1;		//定时器1开始计时
}

void Timer0Init(void)        
{
	AUXR &= 0x80;                //定时器时钟1T模式
	TMOD |= 0x05;                //设置定时器为计数模式
	TL0 = 0x00;                    //设置定时初值
	TH0 = 0x00;                    //设置定时初值
	TF0 = 0;                    //清除TF0标志
	TR0 = 1;                    //定时器0开始计时
}

void  smg_xianshi(uchar yi,er,san,si,wu,liu,qi,ba)
{
	P2=0xc0;
	P0=0x01;
	P2=0xe0;
	P0=tab[yi];
	delay(5);

	P2=0xc0;
	P0=0x02;
	P2=0xe0;
	P0=tab[er];
	delay(5);

	P2=0xc0;
	P0=0x04;
	P2=0xe0;
	P0=tab[san];
	delay(5);

	P2=0xc0;
	P0=0x08;
	P2=0xe0;
	P0=tab[si];
	delay(5);

	P2=0xc0;
	P0=0x10;
	P2=0xe0;
	P0=tab[wu];
	delay(5);        

	P2=0xc0;
	P0=0x20;
	P2=0xe0;
	P0=tab[liu];
	delay(5);

	P2=0xc0;
	P0=0x40;
	P2=0xe0;
	P0=tab[qi];
	delay(5);

	P2=0xc0;
	P0=0x80;
	P2=0xe0;
	P0=tab[ba];
	delay(5);   
}     

void UartInit(void)		//115200bps@11.0592MHz
{
	SCON = 0x50;		//8位数据,可变波特率
	AUXR |= 0x01;		//串口1选择定时器2为波特率发生器
	AUXR |= 0x04;		//定时器2时钟为Fosc,即1T
	T2L = 0xE8;		//设定定时初值
	T2H = 0xFF;		//设定定时初值
	AUXR |= 0x10;		//启动定时器2
}


char putchar(char c)
{
    SBUF=c;
    while(TI!=1);   //等待发送成功
    TI=0;           //清除发送中断标志
    return c;
}


void SendStr(unsigned char *str)
{
    unsigned char *p;

    p = str;
    while(*p != '\0')
    {
        SBUF = *p;
		while(TI == 0);
		TI = 0;
        p++;
    }
}