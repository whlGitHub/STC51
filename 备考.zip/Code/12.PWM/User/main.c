#include "app.h" 
#include "time.h"
#include "PWM.h"

void send_wave(void);
void main()
{
	ClsBuzz();
	SysTickInit();
	UartInit();
	EA=1;
	
	printf("System Init...\r\n");
	steup();

	while(1)
	{
		loop();
	}
}


void steup()
{
	PWMInit(1000);
	DisNum(123);
}


void loop()
{
	static uint8_t duty=0;
	if(KeyInfo.KeyValue==S7)
	{
		static uint32_t TriggerTime=0;
	
		if(millis()>TriggerTime+1)
		{
			
		}
		
	}else
	if(KeyInfo.KeyValue==S6)
	{
		
	}else
	if(KeyInfo.KeyValue==S5)
	{
		
	}else
	if(KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		DisKeuValue();
	}
	{
		static uint8_t PWMFlag=1;
		SetDuty(duty);
		
		if(PWMFlag==0)
		{
			duty--;
			PWMFlag=(duty<=0)?1:0;
		}else
		{
			duty++;
			PWMFlag=(duty>=255)?0:1;
		}
		
	}
	delay(10);
}





