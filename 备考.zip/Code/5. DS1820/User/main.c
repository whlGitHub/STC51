#include "io.h"
#include "onewire.h"

void main()
{
	ClsBuzz();
	SysTickInit();
	UartInit();
	ReadTemp();
	
	steup();
	while(1)
	{
		loop();
	}
}

void steup()
{
	uint16_t temp;
	printf("System initialize...\r\n");
	delay(1000);
	temp=ReadTemp();
	DisNum((uint16_t)temp);
}

void loop()
{
	
	if(KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		DisNum(KeyInfo.KeyValue);
	}
	else
	{
		float temp;
		static uint32_t TriggerTime=0;
		
		if(millis()>TriggerTime+1000)
		{
			TriggerTime=millis();
			temp=ReadTempFloat();
			printf("Temperature is %2.2f\r\n",temp);
			DisNum((uint16_t)temp);
		}
		
	}
	
}

//��ʱ���ж��û�������1msִ��һ��
void INTLoop()
{
	
}
