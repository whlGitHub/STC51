#include "drive.h"
#include "application.h"


uint32_t SysTickCNT=0;
	
void steup();
void loop();

void main()
{
	
	ClsBuzz();
	T0Init();
	UartInit();
	steup();
	SendStr("hello.....\r\n");
	//printf("print test.....\r\n");
	SendStr("test succeed.....\r\n");
	while(1)
	{
		loop();
	}

}

//void led()
//{
//	static char ledflag=0,i;
//	if(SysTickCNT%500!=0)
//		ledflag=1;
//	if(SysTickCNT%500==0&&ledflag==1)
//	{
//		static char led=0;
//		ledflag=0;
//		SingleLed(i++,led);
//		if(i==9)
//		{
//			i=0;
//			led=!led;
//		}
//	}
//}

void steup()
{
	DisRunCount();
	Ds1302Init();
	PCACupture();
	//PWMInit(32);
	//PWMIOSet(7);
	delay(500);
}

void loop()
{
	if(KeyInfo.KeyStatus==KEYDOWN&&KeyInfo.KeyValue==S7)
	{
		DisTemperature(500);
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S7)
	{
		//KeyInfo.Trigger=NONE;
		DisADC();
	}else
	if(KeyInfo.KeyValue==S6)
	{
		//KeyInfo.Trigger=NONE;
		uint32_t FreValue;
		if(SysTickCNT%100==0)
		{
			FreValue=GetFre();
			
			DisNum(FreValue);
		}
		
		//sprintf(BUFF,"freq:%ld\r\n",GetFre());
		SendStr(BUFF);
	}else
	{
		DisTime();
	}
	
}

void T0INT() interrupt 1
{
	
	SysTickCNT++;
	//PWMHC573OFF();
	DisPlay();
	if(SysTickCNT%10==0)
	{
		ReadKey();
	}
	//PWMHC573ON();
}