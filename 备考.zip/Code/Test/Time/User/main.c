#include "drive.h"
#include "application.h"

uint32_t SysTickCNT=0;
	
void steup();
void loop();

void main()
{
	
	ClsBuzz();
	T0Init();
	steup();
	delay(10);
	
	while(1)
	{
		loop();
		
	}

}


void led()
{
	static char ledflag=0,i;
	if(SysTickCNT%500!=0)
		ledflag=1;
	if(SysTickCNT%500==0&&ledflag==1)
	{
		static char led=0;
		ledflag=0;
		SingleLed(i++,led);
		if(i==8)
		{
			i=0;
			led=!led;
		}
	}
}

void steup()
{
	DisRunCount();
	Ds1302Init();
	delay(500);
}

void loop()
{
	
	if(KeyInfo.Trigger==FAILLING&&KeyInfo.KeyValue==S7)
	{
		DisTemperature(500);
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S7)
	{
		//KeyInfo.Trigger=NONE;
		DisADC();
	}else
	{
		DisTime();
	}

	led();
}

void T0INT() interrupt 1
{
	
	SysTickCNT++;
	DisPlay();
	if(SysTickCNT%10==0)
	{
		ReadKey();
	}
}