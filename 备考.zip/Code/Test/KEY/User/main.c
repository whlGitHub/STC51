#include "drive.h"



void steup();
void loop();

void main()
{
	
	ClsBuzz();
	T0Init();
	UartInit();
	steup();
	delay(10);
	
	SendStr("hello STC\r\n");
	while(1)
	{
		loop();
		
	}

}

void steup()
{

}

void loop()
{
	int i;
	
	if(KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		DisNum(KeyInfo.KeyValue);
	}
	
}

void T0INT() interrupt 1
{
	static uint32_t SysTickCNT=0;
	static char led=0;
	SysTickCNT++;
	DisPlay();
	if(SysTickCNT%10==0)
	{
		SingleLed(8,~led);
		ReadKey();
	}
}