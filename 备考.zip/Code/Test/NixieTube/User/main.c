#include "drive.h"

void steup();
void loop();

void main()
{
	
	ClsBuzz();
	T0Init();
	steup();
	delay(10);
	
	while(1)
	{
		loop();
		
	}

}

void steup()
{

}

void loop()
{
	int i;
	
	DisNum(i++);
	delay(500);
}

void T0INT() interrupt 1
{
	DisPlay();
}