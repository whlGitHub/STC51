#include "drive.h"
#include "application.h"

uint32_t SysTickCNT=0;
	
void steup();
void loop();

void main()
{
	
	ClsBuzz();
	//T0Init();
	
	steup();
	
	while(1)
	{
		//loop();
		//PWM2IO=~PWM2IO;
	}

}

void led()
{
	static char ledflag=0,i;
	if(SysTickCNT%500!=0)
		ledflag=1;
	if(SysTickCNT%500==0&&ledflag==1)
	{
		static char led=0;
		ledflag=0;
		SingleLed(i++,led);
		if(i==9)
		{
			i=0;
			led=!led;
		}
	}
}

void steup()
{
	DisRunCount();
	Ds1302Init();
	PWMInit(64);
	delay(500);
}

void loop()
{
	if(KeyInfo.Trigger==FAILLING&&KeyInfo.KeyValue==S7)
	{
		DisTemperature(500);
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S7)
	{
		//KeyInfo.Trigger=NONE;
		DisADC();
	}else
	{
		DisTime();
	}
	//DAC();
	led();
}

void T0INT() interrupt 1
{
	
	SysTickCNT++;
	DisPlay();
	if(SysTickCNT%10==0)
	{
		ReadKey();
	}
}