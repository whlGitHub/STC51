#include "drive.h"

void steup();
void loop();

void main()
{
	
	ClsBuzz();
	T0Init();
	steup();
	delay(10);
	
	while(1)
	{
		loop();
		
	}

}

void steup()
{

}

void loop()
{
	int i;
	
	for(i=1;i<=8;i++)
	{
		//����һ��led	
		LedBit(i);
		delay(500);
		//Ϩ������led
		LedBit(0);
		delay(500);
	}
	
	//ѭ�����ε���led
	for(i=1;i<=8;i++)
	{
		SingleLed(i,1);
		delay(500);
	}
	for(i=8;i>0;i--)
	{
		SingleLed(i,0);
		delay(500);
	}
	
}

void T0INT() interrupt 1
{
	
}