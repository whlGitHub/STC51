#ifndef _APP_H
#define _APP_H

#include "io.h"
#include "iic.h"
#include "onewire.h"
#include "ds1302.h"

void DisRunCount(void);
void Distemp();
void DisADC();
void DisKeuValue();
void DisTime();

#endif