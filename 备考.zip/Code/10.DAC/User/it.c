#include "io.h"

void SysTickHandler() interrupt 12
{
	SysTickCNT++;
	DisPlay();
	if(SysTickCNT%10==0)
	{
		ReadKey();
	}
	
	INTLoop();
}

