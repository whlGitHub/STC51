#include "app.h" 
#include "time.h"
#include "Ultrasonic.h"

void send_wave(void);
void main()
{
	ClsBuzz();
	SysTickInit();
	UartInit();
	Ds1302Init();
	steup();
	EA=1;
	printf("System Init...\r\n");
	FreqInit();
	while(1)
	{
		loop();
	}
}


void steup()
{
	DisRunCount();
	
}


void loop()
{
	if(KeyInfo.KeyValue==S7)
	{
		static uint32_t TriggerTime=0;
	
		if(millis()>TriggerTime+1)
		{
			static uint8_t DACValue=0;
			TriggerTime=millis();
			WriteDAC(DACValue);
			DACValue+=1;
			DisNum(DACValue);
			printf("DAC=%d,vlot=%f\r\n",(uint16_t)DACValue,(float)(DACValue/51.0));
		}
		
	}else
	if(KeyInfo.KeyValue==S6)
	{
		Distemp();
	}else
	if(KeyInfo.KeyValue==S5)
	{
		DisADC();
	}else
	if(KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		DisKeuValue();
	}
}





