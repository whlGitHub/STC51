#ifndef __ONEWIRE_H
#define __ONEWIRE_H

unsigned char ReadTemp(void); 
float ReadTempFloat(void);

#endif
