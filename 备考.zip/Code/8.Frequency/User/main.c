#include "app.h" 
#include "time.h"
void main()
{
	ClsBuzz();
	SysTickInit();
	UartInit();
	Ds1302Init();
	steup();
	EA=1;
	printf("System Init...\r\n");
	FreqInit();
	P3=0xff;
	while(1)
	{
		loop();
	}
}


void steup()
{
	DisRunCount();
	
}


void loop()
{
	if(KeyInfo.KeyValue==S7)
	{
		static uint32_t TriggerTime=0;
	
		if(millis()>TriggerTime+300)
		{
			uint16_t freq=0,length,filter=0;
			TriggerTime=millis();
			
			freq=ReadFreq();
			printf("freq=%d\r\n",freq);
			DisNum(freq);
		}
		
	}else
	if(KeyInfo.KeyValue==S6)
	{
		Distemp();
	}else
	if(KeyInfo.KeyValue==S5)
	{
		DisADC();
	}else
	if(KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		DisKeuValue();
	}
}





