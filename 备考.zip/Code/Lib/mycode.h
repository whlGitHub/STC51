#ifndef MYCODE_H_
#define MYCODE_H_

extern code unsigned char MyCode[];

#endif