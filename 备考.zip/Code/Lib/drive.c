#include "reg52.h"

code BYTE mycode[]=
"\
//////��ʼ�������ļ�////\r\n\
\r\n\
\r\n\
#include  <stc15f2k60s2.h> \r\n\
#include  <absacc.h>  \r\n\
#include  <math.h> \r\n\
#include  <stdio.h> \r\n\
#include  <string.h>  \r\n\
#include  <intrins.h> \r\n\
#define uint unsigned int  \r\n\
#define uchar unsigned char\r\n\
unsigned char dspbuf[8] = {10,10,8,10,10,10,10,10};\r\n\
unsigned char dspcom = 0;\r\n\
code unsigned char tab[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xc6,0x89,0xbf};\r\n\
void display(void);\r\n\
void main(void)\r\n\
{  \r\n\
"
