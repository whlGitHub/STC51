
code unsigned char MyCode[] = "0123456789\r\n";

