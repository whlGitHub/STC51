#include "Frame.h"
#define TimeTaskNum 5

static uint32_t SysTick=0;
sTimeTask TimeTask[TimeTaskNum];

void TimeTaskInit()
{
	int i;
	for(i=0;i<TimeTaskNum;i++)
	{
		TimeTask[i].ms=0;
		TimeTask[i].StartTime=0;
		TimeTask[i].use=0;
		TimeTask[i].LoopFlag=0;
		TimeTask[i].RunFlag=0;
		TimeTask[i].BackCallFun=NULL;
		
	}
}

void TimeTaskRun()
{
	int i;
	
	for(i=0;i<TimeTaskNum;i++)
	{
		if(TimeTask[i].use==1&&TimeTask[i].RunFlag==1)
		{
			TimeTask[i].RunFlag=0;
			if(TimeTask[i].LoopFlag==0)
				TimeEnd(i);
			TimeTask[i].BackCallFun();
		}
	}
}

void TimeSchedul(uint32_t ScheSysTick)
{
	int i;
	SysTick= ScheSysTick/10*10;
	
	for(i=0;i<TimeTaskNum;i++)
	{
		if(TimeTask[i].use==1)
		{
			if((ScheSysTick-TimeTask[i].StartTime)%TimeTask[i].ms==0)
			{
				TimeTask[i].RunFlag=1;
			}
		}
	}
}


int TimeStart(uint16_t ms,FP BackCallFun)
{
	int i;
	for(i=0;i<TimeTaskNum;i++)
	{
		if(TimeTask[i].use!=1)
		{
			TimeTask[i].ms=ms;
			TimeTask[i].StartTime=SysTick;
			TimeTask[i].BackCallFun=BackCallFun;
			TimeTask[i].use=1;
			TimeTask[i].LoopFlag=0;
			return i;
		}
	}
	return -1;
}

void  TimeEnd(int TimeId)
{
	TimeTask[TimeId].use=0;
	
}

int TimeLoopStart(uint16_t ms,FP BackCallFun)
{
	int i;
	for(i=0;i<TimeTaskNum;i++)
	{
		if(TimeTask[i].use!=1)
		{
			TimeTask[i].ms=ms;
			TimeTask[i].StartTime=SysTick;
			TimeTask[i].BackCallFun=BackCallFun;
			TimeTask[i].use=1;
			TimeTask[i].LoopFlag=1;
			return i;
		}
	}
	return -1;
}







