#ifndef _APP_H_
#define _APP_H_

#include "drive.h"
#include "onewire.h"
#include "iic.h"
#include "ds1302.h"


void DisTemperature(int fre);
void DisRunCount(void);
void DisADC(void);
void DisTime(void );
void DAC();

#endif






