#include "application.h"


/**
  * @brief  ��ȡ����ʾ�¶�
  * @param  None
  * @retval None
  * @Note	None
  */
void DisTemperature(int fre)
{
	//static char TempFlag=1;

	if(SysTickCNT%fre==0)
	{
		uint16_t Temperature;
		//TempFlag=0;
		do
		{
			Temperature=ReadTemp();
		}while(Temperature==255||Temperature==127||Temperature==85);
		DisNum(Temperature);
	}
}

//void DisTemperature(int fre)
//{
//	static char TempFlag=1;

//	if(SysTickCNT%fre==0||TempFlag==1)
//	{
//		float Temperature;
//		TempFlag=0;
//		do
//		{
//			Temperature=ReadTempFloat();
//		}while(Temperature==255||Temperature==127);
//		clear();
//		DisBit(1,Temperature/10);
//		DisBit(1,NowDateArray[0]/10);
//	}
//}

void DisRunCount(void)
{
	if(ReadEEPROM(0x01)!=0)
	{
		WriteEEPROM(0x01,0);
		WriteEEPROM(0x00,1);
	}
	else
	{
		uint8_t RunCount;
		RunCount=ReadEEPROM(0x00);
		RunCount++;
		WriteEEPROM(0x00,RunCount);
		DisNum(RunCount);
	}
}

void DisADC(void)
{
	uint16_t ADCValue;
	if(SysTickCNT%100==0)
	{
		ADCValue=ReadADC(3);
		DisNum(ADCValue);
	}
}

void DisTime(void )
{
	if(SysTickCNT%1000==0)
	{
		Ds1302Read();
		DisBit(2,17);
		DisBit(5,17);
		DisBit(0,NowDateArray[0]%10);
		DisBit(1,NowDateArray[0]/10);
		DisBit(3,NowDateArray[1]%10);
		DisBit(4,NowDateArray[1]/10);
		DisBit(6,NowDateArray[2]%10);
		DisBit(7,NowDateArray[2]/10);
	}
}


void DAC()
{
	static char dacflag=0,volt=0;
	if(SysTickCNT%10!=0)
		dacflag=1;
	if(SysTickCNT%10==0&&dacflag==1)
	{
		dacflag=0;
		WriteDAC(volt++);
	}
}
