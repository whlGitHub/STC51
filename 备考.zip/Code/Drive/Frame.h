#ifndef _FRAME_H_
#define _FRAME_H_

//#include "drive.h"

typedef void (*FP)(void); 

typedef struct {
	
	uint32_t StartTime;
	uint16_t ms;
	uint8_t use;
	uint8_t RunFlag;
	uint8_t LoopFlag;
	FP BackCallFun;
}sTimeTask;

typedef struct {
	uint32_t ms;
	uint16_t use;
	FP BackCallFun;
}sTimeLoopTask;

typedef struct {
	eTrigger Trigger;
	eKeyValue KeyValue;
	FP BackCallFun;
}sKeyTask;

int TimeStart(uint16_t ms,FP BackCallFun);
int TimeLoopStart(uint16_t ms,FP BackCallFun);
void  TimeEnd(int TimeId);
void TimeTaskInit();
void TimeTaskRun();
void TimeSchedul(uint32_t ScheSysTick);
void KEYSchedulInit();
void KeyRegister(eTrigger Trigger,eKeyValue KeyValue,FP BackCallFun);
void KeySchedul();

#endif






