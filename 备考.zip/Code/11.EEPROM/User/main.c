#include "app.h" 
#include "time.h"
#include "Ultrasonic.h"

void send_wave(void);
void main()
{
	ClsBuzz();
	SysTickInit();
	UartInit();
	Ds1302Init();
	steup();
	EA=1;
	printf("System Init...\r\n");
	FreqInit();
	while(1)
	{
		loop();
	}
}


void steup()
{
	//DisRunCount();
	char i,array[16]={0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37},temp[16];
	WriteEEPROMData(0x00, array,16);
	delay(10);
	ReadEEPROMData(0x00, temp,16);
	for(i=0;i<16;i++)
	{
		int buff;
		printf("temp:%2x\r\n",(int)temp[i]);
	}
}


void loop()
{
	if(KeyInfo.KeyValue==S7)
	{
		static uint32_t TriggerTime=0;
	
		if(millis()>TriggerTime+1)
		{
			
		}
		
	}else
	if(KeyInfo.KeyValue==S6)
	{
		
	}else
	if(KeyInfo.KeyValue==S5)
	{
		
	}else
	if(KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		DisKeuValue();
	}
}





