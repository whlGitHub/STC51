#include "app.h" 
#include "time.h"

#define WRITEAADDER 0x08

uint16_t S4Count=1,S5Count=0,S6Count=0,S7Count=0;
typedef struct {
	float temp;
	uint16_t volt;
	uint16_t freq;
}sInfo;

void SaveInfo();
void KeyHandler();
void VlotInterface(char mode);
void FreqInterface(char mode);
void TempInterface(char mode);
void VlotSetInterface(float value);

pFun_int Interface[]={VlotInterface,FreqInterface,TempInterface};
float SetVolt=0;

void main()
{
	ClsBuzz();
	SysTickInit();
	UartInit();
	Ds1302Init();
	ReadTempFloat();
	FreqInit();
	EA=1;
	delay(1000);
	printf("System Init...\r\n");
	
	
	steup();
	
	
	while(1)
	{
		loop();
	}
}


void steup()
{
//	ReadEEPROMData(0x20,(unsigned char *)&SetVolt,sizeof(SetVolt));
//	if(SetVolt>5)SetVolt=0;
}


void loop()
{
	KeyHandler();
	
	if(S7Count!=0)
	{
		VlotSetInterface(SetVolt);
	}else
	if(S4Count!=0)
	{
		Interface[S4Count-1](0);		//ִ�к���ת�Ʊ��еĺ���
	}else
	if(S5Count!=0)
	{
		S5Count=0;
		
	}else
	if(S6Count!=0)
	{
		//Interface[S6Count-1](1);		//ִ�к���ת�Ʊ��еĺ���
	}
	
	
}

void KeyHandler()
{
	if(KeyInfo.KeyValue==S7&&KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		S4Count=0;
		if(S7Count==1)
		{
			S7Count=0;
			//WriteEEPROMData(0x20,(unsigned char *)&SetVolt,sizeof(SetVolt));
			
		}
		else
		{
			S7Count=1;
		}
		printf(">>>3: S7Count=%d\r\n",S7Count);
	}else
	if(KeyInfo.KeyValue==S6&&KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		S6Count++;
		printf(">>>2: S6Count=%d\r\n",S6Count);
		S6Count=(S6Count<4)?S6Count:1;
		S4Count=0;
		if(S7Count==1)
		{
			SetVolt+=0.1;
			SetVolt=(SetVolt<5)?SetVolt:0;
		}
	}else
	if(KeyInfo.KeyValue==S5&&KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		//SaveInfo();
		printf(">>>2: S5Count=%d\r\n",S5Count);
		S5Count=1;
		S6Count=0;
	}else
	if(KeyInfo.KeyValue==S4&&KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		S4Count++;
		S6Count=0;
		S4Count=(S4Count<4)?S4Count:1;
		printf(">>>1: S4Count=%d\r\n",S4Count);
	}else
	if(KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		DisKeuValue();
	}
}

void SaveInfo()
{
	int i;
	sInfo Info,Info2;
	Info.temp=ReadTempFloat();
	Info.volt=ReadADC(3);
	Info.freq=ReadFreq();
	WriteEEPROMData(WRITEAADDER,(unsigned char*)&Info,sizeof(sInfo));
	for(i=0;i<sizeof(sInfo);i++)
	{
		printf("Info[%d]:%x\r\n",i,((unsigned char*)&Info)[i]);
	}
	delay(10);
	//ReadEEPROMData(WRITEAADDER,(unsigned char*)&Info2,sizeof(sInfo));
	printf("temp:%2.2f,vlot:%d,freq:%d\r\n",Info2.temp,Info2.volt,Info2.freq);
}

void VlotInterface(char mode)
{
	float ADCvalue,volt;
	static uint32_t TriggerTime=0;
	if(millis()>TriggerTime+300)
	{
		TriggerTime=millis();
		
//		if(mode==1)
//		{
//			sInfo Info;
//			
//			//ReadEEPROMData(WRITEAADDER,(unsigned char*)&Info,sizeof(sInfo));
//			DisNumFloat(Info.volt/51.0,1);
//			DisBit(7,29);
//			DisBit(6,36);
//			printf("temp:%2.2f,vlot:%d,freq:%d\r\n",Info.temp,Info.volt,Info.freq);
//		}else
		{
			
			ADCvalue= (float)ReadADC(3);
			volt=ADCvalue/51.0;
			DisNumFloat(volt,1);
			DisBit(7,36);
			printf("ADC Value is %2.1f,%d\r\n",volt,(int)ADCvalue);
		}
		
		
	}
}

void VlotSetInterface(float value)
{
	static uint32_t TriggerTime=0;
	if(millis()>TriggerTime+300)
	{
		TriggerTime=millis();
		DisNumFloat(value,1);
		DisBit(7,35);
		printf("ADC Value set is %2.1f\r\n",value);
	}
}

void FreqInterface(char mode)
{
	uint16_t freq;
	static uint32_t TriggerTime=0;
	if(millis()>TriggerTime+300)
	{
		TriggerTime=millis();
		if(mode==1)
		{
			sInfo Info;
			//ReadEEPROMData(WRITEAADDER,(unsigned char*)&Info,sizeof(sInfo));
			DisNum(Info.freq);
			DisBit(7,29);
			DisBit(6,15);
			printf("temp:%2.2f,vlot:%d,freq:%d\r\n",Info.temp,Info.volt,Info.freq);
		}else
		{
			freq= ReadFreq(); 
			DisNum(freq);
			DisBit(7,15);
			printf("freq is %d\r\n",freq);
		}

	}
}

void TempInterface(char mode)
{
	float temp;
	static uint32_t TriggerTime=0;
	if(millis()>TriggerTime+500)
	{
		TriggerTime=millis();
		
		if(mode==1)
		{
			sInfo Info;
			//ReadEEPROMData(WRITEAADDER,(unsigned char*)&Info,sizeof(sInfo));
			DisNumFloat(Info.temp,2);
			DisBit(7,29);
			DisBit(6,12);
			printf("temp:%2.2f,vlot:%d,freq:%d\r\n",Info.temp,Info.volt,Info.freq);
		}else
		{
			
			temp= ReadTempFloat(); 
			DisNumFloat(temp,2);
			DisBit(7,12);
			printf("temp is %2.2f\r\n",temp);
		}
		
	}
}
