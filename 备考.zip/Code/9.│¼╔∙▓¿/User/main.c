#include "app.h" 
#include "time.h"
#include "Ultrasonic.h"

void send_wave(void);
void main()
{
	ClsBuzz();
	SysTickInit();
	UartInit();
	Ds1302Init();
	steup();
	EA=1;
	printf("System Init...\r\n");
	FreqInit();
	while(1)
	{
		loop();
	}
}


void steup()
{
	DisRunCount();
	
}


void loop()
{
	if(KeyInfo.KeyValue==S7)
	{
		static uint32_t TriggerTime=0;
	
		if(millis()>TriggerTime+500)
		{
			uint16_t freq=0;
			TriggerTime=millis();
			
			freq=distance();
			printf("freq=%d\r\n",freq);
			DisNum(freq);
		}
		
	}else
	if(KeyInfo.KeyValue==S6)
	{
		Distemp();
	}else
	if(KeyInfo.KeyValue==S5)
	{
		DisADC();
	}else
	if(KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		DisKeuValue();
	}
}





