#ifndef _APP_H_
#define _APP_H_

#include "drive.h"
#include "onewire.h"

void DisTemperature(int fre);

#endif






