#include "application.h"

/**
  * @brief  ��ȡ����ʾ�¶�
  * @param  None
  * @retval None
  * @Note	None
  */
void DisTemperature(int fre)
{
	//static char TempFlag=1;

	if(SysTickCNT%fre==0)
	{
		uint16_t Temperature;
		do
		{
			Temperature=ReadTemp();
		}while(Temperature==255||Temperature==127||Temperature==85);
		DisBit(0,12);
		DisBit(1,Temperature%10);
		DisBit(2,Temperature/10%10);
		DisBit(3,16);
		DisBit(4,16);
		DisBit(5,17);
		DisBit(6,4);
		DisBit(7,17);
	}
}


