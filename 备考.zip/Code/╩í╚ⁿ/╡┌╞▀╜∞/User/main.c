#include "drive.h"
#include "application.h"

uint32_t SysTickCNT=0;

uint16_t RunTime=60;
	
void steup();
void loop();

void main()
{
	ClsBuzz();
	
	T1Init();
	UartInit();
	steup();
	SendStr("hello.....\r\n");
	while(1)
	{
		loop();
	}

}


void steup()
{
	T0Init();
	PWMInit(51);
	LedBit(1);
	PWMHC573ON();
}

static uint16_t S4Count=0;
void PWMModeSet()
{
	S4Count++;
	if(S4Count>=3)
	{S4Count=0;}
	
	if(S4Count==0)
	{
		PWMInit(51);
	}
	else if(S4Count==1)
	{
		PWMInit(128);
	}
	else if(S4Count==2)
	{
		PWMInit(178);
	}
}

void Disled()
{
	if(RunTime!=0)
	{
		//PWMHC573ON();
		if(S4Count==0)
		{
			LedBit(1);
		}
		else if(S4Count==1)
		{
			LedBit(2);
		}
		else if(S4Count==2)
		{
			LedBit(3);
		}
	}
	else
	{
		LedBit(0);
		//PWMHC573OFF();
	}
	
}

void SetRunTime()
{
	static uint16_t S5Count=0;
	S5Count++;
	if(S5Count>=3)
	{S5Count=0;}
	
	if(S5Count==0)
	{
		RunTime=0;
	}
	else if(S5Count==1)
	{
		RunTime=60;
	}
	else if(S5Count==2)
	{
		RunTime=120;
	}
}

void disPWM()
{
	DisBit(0,RunTime%10);
	DisBit(1,RunTime/10%10);
	DisBit(2,RunTime/100%10);
	DisBit(3,RunTime/1000%10);
	DisBit(4,16);
	DisBit(5,17);
	DisBit(6,S4Count+1);
	DisBit(7,17);
}

void loop()
{
	static uint16_t S7Count=0;
	
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S4)
	{
		KeyInfo.Trigger=NONE;
		PWMModeSet();
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S5)
	{
		KeyInfo.Trigger=NONE;
		SetRunTime();
		
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S6)
	{
		KeyInfo.Trigger=NONE;
		RunTime=0;
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S7)
	{
		KeyInfo.Trigger=NONE;
		S7Count++;

		if(S7Count>=2)
		{
			S7Count=0;	
		}
		
	}else
	{
		if(S7Count==0)
		{
			disPWM();
		}
		else
		{
			DisTemperature(200);
		}
	}
	
//	if(S7Count==1)
//	{
//		SendStr("S7Count=0 ִ��\r\n");
//		DisTemperature(200);
//	}
//	else
//	{
//		SendStr("S7Count=1 ִ��\r\n");
//		DisBit(0,RunTime%10);
//		DisBit(1,RunTime/10%10);
//		DisBit(2,RunTime/100%10);
//		DisBit(3,RunTime/1000%10);
//		DisBit(4,16);
//		DisBit(5,17);
//		DisBit(6,S4Count+1);
//		DisBit(7,17);
//	}
}

void T1INT() interrupt 3
{
	SysTickCNT++;
	DisPlay();
	Disled();
	if(SysTickCNT%10==0)
	{
		ReadKey();
	}
	if(SysTickCNT%1000==0)
	{
		if(RunTime!=0)
		{
			RunTime--;
			PWMHC573ON();
		}
		else
		{
			PWMHC573OFF();
		}
	}
}