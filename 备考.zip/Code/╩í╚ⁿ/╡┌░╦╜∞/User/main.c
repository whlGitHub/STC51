#include "drive.h"
#include "application.h"

void steup();
void loop();

void main()
{
	ClsBuzz();
	T1Init();
	Ds1302Init();
	UartInit();
	steup();
	SendStr("hello.....\r\n");
	while(1)
	{
		loop();
	}
}

void steup()
{
	
	LedBit(0);
}

uint16_t S6Count=0,S7Count=0;
uint16_t AlarmActionFlag=0;
uint8_t Alarm[3]={0,0,0};		//�룬�֣�ʱ

void BlinkTime()
{
	static uint16_t BlinkFlag=1,Trigger=0;
	DisTime();
	
	if(SysTickCNT%1000!=0)
	{
		Trigger=1;
	}
	
	if(SysTickCNT%1000==0&&Trigger==1)
	{
		Trigger=0;
		BlinkFlag=!BlinkFlag;
	}
	
	if(BlinkFlag==1)
	{
		if(S7Count==1)
		{
			DisBit(6,16);
			DisBit(7,16);
		}else
		if(S7Count==2)
		{
			DisBit(4,16);
			DisBit(3,16);
		}else
		if(S7Count==3)
		{
			DisBit(1,16);
			DisBit(0,16);
		}
	}
}



void DisAlarm()
{
	DisBit(2,17);
	DisBit(5,17);
	DisBit(0,Alarm[0]%10);
	DisBit(1,Alarm[0]/10);
	DisBit(3,Alarm[1]%10);
	DisBit(4,Alarm[1]/10);
	DisBit(6,Alarm[2]%10);
	DisBit(7,Alarm[2]/10);
}


void BlinkAlarm()
{
	
	static uint16_t BlinkFlag=1,Trigger=0;
	
	
	if(SysTickCNT%1000!=0)
	{
		Trigger=1;
	}
	
	if(SysTickCNT%1000==0&&Trigger==1)
	{
		Trigger=0;
		BlinkFlag=!BlinkFlag;
	}
	
	if(BlinkFlag==1)
	{
		if(S6Count==1)
		{
			DisBit(6,16);
			DisBit(7,16);
			DisBit(2,17);
			DisBit(5,17);
			DisBit(0,Alarm[0]%10);
			DisBit(1,Alarm[0]/10);
			DisBit(3,Alarm[1]%10);
			DisBit(4,Alarm[1]/10);
		}else
		if(S6Count==2)
		{
			DisBit(4,16);
			DisBit(3,16);
			DisBit(2,17);
			DisBit(5,17);
			DisBit(0,Alarm[0]%10);
			DisBit(1,Alarm[0]/10);
			DisBit(6,Alarm[2]%10);
			DisBit(7,Alarm[2]/10);

		}else
		if(S6Count==3)
		{
			DisBit(1,16);
			DisBit(0,16);
			DisBit(2,17);
			DisBit(5,17);
			DisBit(3,Alarm[1]%10);
			DisBit(4,Alarm[1]/10);
			DisBit(6,Alarm[2]%10);
			DisBit(7,Alarm[2]/10);
		}
	}else
	{
		DisAlarm();
	}
}

static uint32_t AlarmTriggerTime;
void AlarmCheck()
{
	int i=0;
	uint16_t AlarmFlag=1;
	
	for(i=0;i<3;i++)		//�������ʱ���Ƿ����
	{
		if(Alarm[i]!=NowDateArray[i])
		{AlarmFlag=0;}
	}
	
	if(AlarmFlag==1)		//���������ʱ�䵽
	{
		AlarmActionFlag=1;
		AlarmTriggerTime=SysTickCNT;
	}
}

void AlarmRun()
{
	static uint8_t ledflag=0,Trigger=0;
	
	if(AlarmTriggerTime+5000<=SysTickCNT)
	{AlarmActionFlag=0;}
	
	if(AlarmActionFlag==1)
	{
		if(SysTickCNT%200!=0)
		{
			Trigger=1;
		}
		
		if(SysTickCNT%200==0&&Trigger==1)
		{
			if(ledflag==0)
			{
				ledflag=1;
				LedBit(0);
			}else
			{
				ledflag=0;
				LedBit(1);
			}
		}
	}
	else
	{
		LedBit(0);
	}
}

void loop()
{
	//static uint16_t S6Count=0,S5Count=0;
	
	if(KeyInfo.Trigger!=NONE)AlarmActionFlag=0;
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S7)
	{
		KeyInfo.Trigger=NONE;
		S6Count=0;
		S7Count++;
		if(S7Count>=4)
		{S7Count=0;}
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S6)
	{
//		int i;
		KeyInfo.Trigger=NONE;
		S7Count=0;
		S6Count++;
		if(S6Count>=4)
		{S6Count=0;}
		
//		if(S6Count==1)
//		{
//			Ds1302Read();
//			for(i=0;i<3;i++)
//			{
//				Alarm[i]=NowDateArray[i];
//			}
//		}
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S5)
	{
		KeyInfo.Trigger=NONE;
		if(S7Count!=0)
		{
			if(NowDateArray[3-S7Count]==23&&S7Count==1)		//�������ʱ��Ϊ23�����һ������
			{
				Ds1302Amend(S7Count, 0);
			}else
			if(NowDateArray[3-S7Count]==59&&S7Count!=1)		//������ڷ����������Ϊ59�����һ������
			{
				Ds1302Amend(S7Count, 0);
			}else
			Ds1302Amend(S7Count, ++NowDateArray[3-S7Count]);
		}
		if(S6Count!=0)
		{
			if(Alarm[3-S6Count]==23&&S6Count==1)		//�������ʱ��Ϊ23�����һ������
			{
				Alarm[1]=0;
			}else
			if(Alarm[3-S6Count]==59&&S6Count!=1)		//������ڷ����������Ϊ59�����һ������
			{
				Alarm[2]=0;
			}else
			Alarm[3-S6Count]++;
		}
	}else
	if(KeyInfo.Trigger==FAILLING&&KeyInfo.KeyValue==S4)
	{
		DisTemperature(200);
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S4)
	{
		KeyInfo.Trigger=NONE;
		if(S7Count!=0)
		{
			if(NowDateArray[3-S7Count]==0&&S7Count==1)		//�������ʱ��Ϊ23�����һ������
			{
				Ds1302Amend(S7Count, 23);
			}else
			if(NowDateArray[3-S7Count]==0&&S7Count!=1)		//������ڷ����������Ϊ59�����һ������
			{
				Ds1302Amend(S7Count, 59);
			}else
			Ds1302Amend(S7Count, --NowDateArray[3-S7Count]);
		}else
		if(S6Count!=0)
		{
			if(Alarm[1]==0&&S6Count==1)		//�������ʱ��Ϊ23�����һ����23
			{
				Alarm[1]=23;
			}else
			if(Alarm[3-S6Count]==0&&S6Count!=1)		//������ڷ����������Ϊ59�����һ����59
			{
				Alarm[2]=59;
			}else
			Alarm[3-S6Count]--;
		}
	}else
	{
		//S6Count=0;
		BlinkTime();
	}

	if(S6Count==1||S6Count==2||S6Count==3)
	{
		BlinkAlarm();
	}
	
//	AlarmCheck();
//	AlarmRun();
}

void INTLoop()
{
	AlarmCheck();
	AlarmRun();
}


