#include "drive.h"
#include "application.h"

void steup();
void loop();

void main()
{
	ClsBuzz();
	T2Init();
	Ds1302Init();
	UartInit();
	steup();
	SendStr("hello.....\r\n");
	while(1)
	{
		loop();
	}
}

void steup()
{
	
	LedBit(0);
}

void  DisRange()
{
	uint16_t juli;
	if(SysTickCNT%200==0)
	{
		juli=ceju();
		clear();
		DisNum(juli);
	}
}

void loop()
{
	if(KeyInfo.Trigger!=NONE)		//���ⰴ��
	{
		
	}
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S7)
	{
		
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S6)
	{
		
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S5)
	{
		
	}else
	if(KeyInfo.Trigger==FAILLING&&KeyInfo.KeyValue==S4)
	{
		
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S4)
	{
		if(SysTickCNT%200==0)
		{
			DisNum(123);
		}
	}else
	{
		//DisRange();
	}
	led=~led;
	

}

void INTLoop()
{
	
}


