#include "application.h"

/**
  * @brief  ��ȡ����ʾ�¶�
  * @param  None
  * @retval None
  * @Note	None
  */
void DisTemperature(int fre)
{
	
	if(SysTickCNT%fre==0)
	{
		uint16_t Temperature;
		do
		{
			Temperature=ReadTemp();
		}while(Temperature==255||Temperature==127||Temperature==85);
		
		DisBit(0,12);
		DisBit(1,Temperature%10);
		DisBit(2,Temperature/10%10);
		DisBit(3,16);
		DisBit(4,16);
		DisBit(5,16);
		DisBit(6,16);
		DisBit(7,16);
	}
}

void DisTime(void )
{
	if(SysTickCNT%1000==0)
	{
		Ds1302Read();
		DisBit(2,17);
		DisBit(5,17);
		DisBit(0,NowDateArray[0]%10);
		DisBit(1,NowDateArray[0]/10);
		DisBit(3,NowDateArray[1]%10);
		DisBit(4,NowDateArray[1]/10);
		DisBit(6,NowDateArray[2]%10);
		DisBit(7,NowDateArray[2]/10);
	}
}

void LedBlink()
{
	static uint8_t ledflag=0,Trigger=0;

	if(SysTickCNT%200!=0)
	{Trigger=1;}
	
	if(SysTickCNT%200==0&&Trigger==1)
	{
		if(ledflag==0)
		{
			ledflag=1;
			LedBit(0);
		}else
		{
			ledflag=0;
			LedBit(1);
		}
	}
	
}

