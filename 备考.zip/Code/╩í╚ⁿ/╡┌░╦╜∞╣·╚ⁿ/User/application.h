#ifndef _APP_H_
#define _APP_H_

#include "drive.h"
#include "onewire.h"
#include "ds1302.h"

void DisTemperature(int fre);
void DisTime(void );
void LedBlink();


#endif






