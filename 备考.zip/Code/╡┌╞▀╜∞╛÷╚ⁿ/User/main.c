#include "app.h" 
#include "time.h"


void main()
{
	ClsBuzz();
	SysTickInit();
	UartInit();
	EA=1;
	
	printf("System Init...\r\n");
	steup();

	while(1)
	{
		loop();
		
	}
}


void steup()
{
	FreqInit();
	Ds1302Init();
}


void loop()
{
	static uint8_t num=0;
	if(KeyInfo.KeyValue==S7)
	{
		static uint32_t TriggerTime=0;
	
		if(millis()>TriggerTime+200)
		{
			TriggerTime=millis();
			DisTime();
		}
	}else
	if(KeyInfo.Trigger==FAILLING&&KeyInfo.KeyValue==S6)
	{
		KeyInfo.Trigger=NONE;
		printf("key=%d\r\n",(int)KeyInfo.KeyValue);
		DisNum(num++);
	}else
	if((KeyInfo.Trigger==FAILLING)&&(KeyInfo.KeyValue==(S4|S5)))
	{
		KeyInfo.Trigger=NONE;
		printf(">>>1:key=%d,%d\r\n",(int)KeyInfo.KeyValue,(int)KeyInfo.Trigger);
		DisNum(0xff);
		DisBit(7,15);
	}else
	if(KeyInfo.Trigger==FAILLING)
	{
		DisNum(KeyInfo.KeyValue);	
	}
	
	if(KeyInfo.KeyStatus==LONGPRESS&&KeyInfo.KeyValue==S6)
	{
		static uint32_t TriggerTime=0;
	
		if(millis()>TriggerTime+200)
		{
			TriggerTime=millis();
			DisNum(num++);
		}
	}
}





