#include "io.h"

void main()
{
	ClsBuzz();
	SysTickInit();
	UartInit();
	steup();
	
	while(1)
	{
		loop();
	}
}

void steup()
{
	printf("System initialize...\r\n");
}

void loop()
{
	
	if(KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		DisNum(KeyInfo.KeyValue);
	}
	
}

//��ʱ���ж��û�������1msִ��һ��
void INTLoop()
{
	
}