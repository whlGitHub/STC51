#include "app.h" 
#include "time.h"
#include "Ultrasonic.h"

#define WRITEAADDER 0x08

uint16_t S4Count=1,S5Count=0,S6Count=0,S7Count=0;
static uint16_t DistanceBuff[4];
uint16_t Threshold,ThresholdTemp;
uint16_t LedFlag=0;

void KeyHandler();

void RangingInterface(char mode);
void DataEcho(uint8_t value);	
void SetParameter(uint16_t vlaue);
void DACOUT();

void main()
{
	ClsBuzz();
	SysTickInit();
	UartInit();
	Ds1302Init();
	ReadTempFloat();
	FreqInit();
	EA=1;
	printf("System Init...\r\n");
	
	steup();
	
	while(1)
	{
		loop();
	}
}


void steup()
{
	ReadEEPROMData(0x00, (unsigned char * )DistanceBuff,sizeof(DistanceBuff));
	ReadEEPROMData(0x16,(unsigned char * )Threshold,sizeof(Threshold));
	printf(">>>2: Threshold=%d\r\n",Threshold);
	ThresholdTemp=Threshold;
}


void loop()
{
	KeyHandler();
	if(S6Count==1)
	{
		static uint32_t TriggerTime=0;
		if(millis()>TriggerTime+200)
		{
			TriggerTime=millis();
			ThresholdTemp=Threshold+10*S7Count;
			ThresholdTemp=(ThresholdTemp<=30)?ThresholdTemp:0;
			SetParameter(ThresholdTemp);
			
		}
		
	}else
	if(S5Count==1)
	{
		static uint32_t TriggerTime=0;
		if(millis()>TriggerTime+200)
		{
			TriggerTime=millis();
			DataEcho(S7Count);
		}
	}
	else
	{
		RangingInterface(0);
	}
	if(LedFlag==1)
	{
		static uint32_t TriggerTime=0;
		static uint8_t count=0,LedStatus=1;
		if(millis()>TriggerTime+1000)
		{
			TriggerTime=millis();
			if(count<6)
			{
				SingleLed(1,LedStatus);
				LedStatus=(LedStatus==0)?1:0;
				count++;
			}
			else
			{
				LedFlag=0;
			}
		}
	}
	else
	{
		RangingInterface(0);
	}
	DACOUT();
	
}

void KeyHandler()
{
	if(KeyInfo.KeyValue==S7&&KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		
		S7Count++;
		S7Count=(S7Count<4)?S7Count:0;
		
		
		printf(">>>3: S7Count=%d\r\n",S7Count);
	}else
	if(KeyInfo.KeyValue==S6&&KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		
		
		if(S6Count==1)
		{
			S7Count=0;
			S6Count=0;
			S5Count=0;
			SingleLed(7,0);
			Threshold=ThresholdTemp;
			WriteEEPROMData(0x16,(unsigned char * )Threshold,sizeof(Threshold));	
		}
		else
		{
			SingleLed(7,1);
			S6Count=1;
			S5Count=0;
		}
		

	}else
	if(KeyInfo.KeyValue==S5&&KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		
		printf(">>>1: S5Count=%d\r\n",S5Count);
		S4Count=0;
		if(S5Count==1)
		{
			S7Count=0;
			S5Count=0;
			SingleLed(8,0);
		}
		else
		{
			S5Count=1;
			SingleLed(8,1);
		}
		
	}else
	if(KeyInfo.KeyValue==S4&&KeyInfo.Trigger==FAILLING)
	{
		KeyInfo.Trigger=NONE;
		
		S4Count++;
		S4Count=(S4Count<4)?S4Count:1;
		S5Count=0;
		LedFlag=1;
		RangingInterface(1);
		printf(">>>0: S4Count=%d\r\n",S4Count);
	}
}

void RangingInterface(char mode)
{
	uint16_t temp=0,temp2=0;

	if(mode==1)
	{
		temp=distance();
		DistanceBuff[3]=DistanceBuff[2];
		DistanceBuff[2]=DistanceBuff[1];
		DistanceBuff[1]=DistanceBuff[0];
		DistanceBuff[0]=temp;
		WriteEEPROMData(0x00, (unsigned char * )DistanceBuff,sizeof(DistanceBuff));
	}
	
	DisBit(7,12);
	DisBit(6,16);
	DisBit(3,DistanceBuff[0]%10);
	DisBit(4,DistanceBuff[0]/10%10);
	DisBit(5,DistanceBuff[0]/100%10);
	
	DisBit(0,DistanceBuff[1]%10);
	DisBit(1,DistanceBuff[1]/10%10);
	DisBit(2,DistanceBuff[1]/100%10);
}

void DataEcho(uint8_t value)	
{
	clear();
	DisBit(7,value);
	DisBit(0,DistanceBuff[value]%10);
	DisBit(1,DistanceBuff[value]/10%10);
	DisBit(2,DistanceBuff[value]/100%10);
}

void SetParameter(uint16_t vlaue)
{
	clear();	
	DisBit(7,15);
	DisBit(0,vlaue%10);
	DisBit(1,vlaue/10%10);
	DisBit(2,vlaue/100%10);
}

void DACOUT()
{
	if(DistanceBuff[0]<Threshold)
	{
		WriteDAC(0);
	}else
	{
		uint16_t volt;
		volt=(uint16_t)(DistanceBuff[0]-Threshold);
		volt=(volt>255)?255:volt;
		WriteDAC(volt);
	}
}

