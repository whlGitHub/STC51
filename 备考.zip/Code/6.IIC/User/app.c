#include "app.h"

void DisRunCount(void)
{
	if(ReadEEPROM(0x01)!=0)
	{
		WriteEEPROM(0x01,0);	//���б�־λ
		WriteEEPROM(0x00,1);	//���д���
	}
	else
	{
		uint8_t RunCount;
		RunCount=ReadEEPROM(0x00);
		RunCount++;
		WriteEEPROM(0x00,RunCount);
		DisNum(RunCount);
	}
}

void Distemp()
{
	float temp;
	static uint32_t TriggerTime=0;
	
	if(millis()>TriggerTime+1000)
	{
		TriggerTime=millis();
		temp=ReadTempFloat();
		printf("Temperature is %2.2f\r\n",temp);
		DisNum((uint16_t)temp);
	}
}

void DisADC()
{
	uint8_t ADCvalue;
	static uint32_t TriggerTime=0;
	if(millis()>TriggerTime+300)
	{
		TriggerTime=millis();
		ADCvalue= ReadADC(1); 
		printf("ADC Value is %d\r\n",(uint16_t)ADCvalue);
		DisNum(ADCvalue);
	}
	
}

void DisKeuValue()
{
	static uint32_t TriggerTime=0;
	
	if(millis()>TriggerTime+300)
	{
		TriggerTime=millis();
		DisNum(KeyInfo.KeyValue);
		printf("Key Value is %d\r\n",(uint16_t)KeyInfo.KeyValue);
	}
}
