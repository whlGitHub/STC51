#ifndef _APP_H
#define _APP_H

#include "io.h"
#include "iic.h"
#include "onewire.h"

void DisRunCount(void);
void Distemp();
void DisADC();
void DisKeuValue();

#endif