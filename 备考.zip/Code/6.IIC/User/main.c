#include "io.h"
#include "onewire.h"
#include "app.h" 

void main()
{
	ClsBuzz();
	SysTickInit();
	UartInit();
	steup();
	
	while(1)
	{
		loop();
	}
}

void steup()
{
	DisRunCount();
}

void loop()
{
	
	if(KeyInfo.KeyValue==S7)
	{
		Distemp();
	}else
	if(KeyInfo.KeyValue==S6)
	{
		DisADC();
	}else
	{
		DisKeuValue();
	}
}

//��ʱ���ж��û�������1msִ��һ��
void INTLoop()
{
	
}
