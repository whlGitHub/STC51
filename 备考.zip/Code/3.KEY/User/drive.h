#ifndef _DRIVE_H_
#define _DRIVE_H_

#include <STC15F2K60S2.H>
#include "intrins.h"
#include "stdio.h"

#define FOCS 11059200UL

#define uint unsigned int
#define uchar unsigned char

typedef unsigned long uint32_t;
typedef unsigned int uint16_t;
typedef unsigned char uint8_t;

//���尴��״̬ö�ٱ������ͣ����𣬰��£��ȴ�
typedef enum{KEYUP=0,KEYDOWN=1,KEYWAIT=2} eKeyStatus;
//���尴����ֵö�ٱ�������
typedef enum{   S7=0,S11,S15,S19,
                S6,S10,S14,S18,
                S5,S9,S13,S17,
                S4,S8,S12,S16} eKeyValue;
//          �����أ�  �½���
typedef enum {RISING=0,FAILLING,NONE}eTrigger;

//���尴����Ϣ�ṹ��
typedef struct
{
    eKeyStatus  KeyStatus;
    eKeyValue   KeyValue;
    eTrigger    Trigger;
}sKeyInfo;

extern sKeyInfo KeyInfo;
extern uint32_t SysTickCNT;

sbit    led=P3^4;

void ClsBuzz();
void T0Init();
void T1Init();

void delay(int ms);
void HC573(char num, char dat);

void LedBit(char num);
void GroupLed(char dat);
uint8_t SingleLed(char num,char dat);

void clear();
void DisPlay(void);
void DisBit(char num, char dat);
void DisNum(unsigned long int num);

char ScanKey(void);
void ReadKey(void);
sKeyInfo ReadKeyValue(void);

void INTLoop();

#endif



