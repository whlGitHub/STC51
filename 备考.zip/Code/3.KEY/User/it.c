#include "drive.h"

void T1INT() interrupt 3
{
	led=~led;
	SysTickCNT++;
	DisPlay();
	if(SysTickCNT%10==0)
	{
		ReadKey();
	}
	
	INTLoop();
}

