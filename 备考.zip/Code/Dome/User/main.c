#include "drive.h"
#include "application.h"

void steup();
void loop();
void KeyHandle();


void main()
{
	ClsBuzz();
	T1Init();
	UartInit();
	steup();
	SendStr("hello.....\r\n");
	while(1)
	{
		loop();
	}
}

void steup()
{
	LedBit(0);
	 PCACupture();
}

void loop()
{
	KeyHandle();

}
uint16_t fre;

void INTLoop()
{
	if(SysTickCNT%100==0)
	{
		fre=GetFre()*10;
		PCACupture();
	}
}

void KeyHandle()
{
	if(KeyInfo.Trigger!=NONE)
	{
		
	}
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S7)
	{
		
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S6)
	{
		
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S5)
	{
		if(SysTickCNT%200==0)
		{

		}
	}else
	if(KeyInfo.Trigger==FAILLING&&KeyInfo.KeyValue==S4)
	{
	}else
	if(KeyInfo.Trigger==RISING&&KeyInfo.KeyValue==S4)
	{
		if(SysTickCNT%200==0)
		{
			DisNum(999);
		}
	}else
	{
		
		DisNum(fre);
		
	}
}
