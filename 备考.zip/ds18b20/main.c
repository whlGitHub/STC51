#include<STC15F2K60S2.H>
#include<intrins.h>
#include<stdio.h>
#define uchar unsigned char
#define uint unsigned int

void All_Init();
void Dis_Bit(uchar com,uchar singlenum);
void delay(uint t);
void Read_KBD();

void UartInit(void)	;
char putchar(char c);
void SendStr(unsigned char *str);

uchar key_value,read_buf;
const uchar code dscom[] = {0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0xff};
const uchar code dsnum[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};

void Delay500us();
void Delay80us();
void Write_DS18B20(unsigned char dat);
unsigned char Read_DS18B20(void);
void init_ds18b20(void);
long Read_Temp();

void main()
{
	long temp;
	All_Init();
	UartInit();
	printf("start\r\n");
	while(1)
	{	
		temp = Read_Temp();
		printf("%ld\r\n",temp);
		delay(1000);
	}
	
}


void All_Init()
{
	P2 = 0xA0;
	P0 = 0x00;//关闭蜂鸣器

	P2 = 0x80;
	P0 = 0xFF;//关闭led灯

	P2 = 0xC0;
	P0 = 0xFF;
	P2 = 0xE0;
	P0 = 0xFF;
}

void Dis_Bit(uchar com,uchar singlenum)
{
	P2 = 0xC0;
	P0 = dscom[com];
	P2 = 0xE0;
	P0 = dsnum[singlenum];
	P2 = 0xFF;
	delay(5);
}

void delay(uint t)
{
	uint i;
	while(t--)
		for(i=0;i<845;i++);
}

sbit r1 = P3^0;
sbit r2 = P3^1;
sbit r3 = P3^2;
sbit r4 = P3^3;
sbit c1 = P4^4;
sbit c2 = P4^2;
sbit c3 = P3^5;
sbit c4 = P3^4;

void Read_KBD()
{
	uchar key_buf = 0;
	static key_state = 0;
	c1 = 0;
	c2 = c3 = c4 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 7;
	else if(!r2) key_buf = 6;
	else if(!r3) key_buf = 5;
	else if(!r4) key_buf = 4;

	c2 = 0;
	c1 = c3 = c4 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 11;
	else if(!r2) key_buf = 10;
	else if(!r3) key_buf = 9;
	else if(!r4) key_buf = 8;
	
	c3 = 0;
	c1 = c2 = c4 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 15;
	else if(!r2) key_buf = 14;
	else if(!r3) key_buf = 13;
	else if(!r4) key_buf = 12;

	c4 = 0;
	c1 = c2 = c3 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 19;
	else if(!r2) key_buf = 18;
	else if(!r3) key_buf = 17;
	else if(!r4) key_buf = 16;

	switch(key_state)
	{
		case 0:
			if(key_buf != 0)
			{
				read_buf = key_buf;
				key_state = 1;
			}
			break;
		case 1:
			if(read_buf == key_buf)
			{
				key_value = read_buf;
				key_state = 2;
			}
			break;
		case 2:
			if(key_buf == 0)
			{
				key_state = 0;
			}
			break;
		default:break;
	}
}


void UartInit(void)		//115200bps@11.0592MHz
{
	SCON = 0x50;		//8位数据,可变波特率
	AUXR |= 0x40;		//定时器1时钟为Fosc,即1T
	AUXR &= 0xFE;		//串口1选择定时器1为波特率发生器
	TMOD &= 0x0F;		//设定定时器1为16位自动重装方式
	TL1 = 0xE8;		//设定定时初值
	TH1 = 0xFF;		//设定定时初值
	ET1 = 0;		//禁止定时器1中断
	TR1 = 1;		//启动定时器1
}


char putchar(char c)
{
    SBUF=c;
    while(TI!=1);   //等待发送成功
    TI=0;           //清除发送中断标志
    return c;
}


void SendStr(unsigned char *str)
{
    unsigned char *p;

    p = str;
    while(*p != '\0')
    {
        SBUF = *p;
		while(TI == 0);
		TI = 0;
        p++;
    }
}

sbit DQ = P1^4;  //单总线接口

//通过单总线向DS18B20写一个字节
void Write_DS18B20(unsigned char dat)
{
	unsigned char i;
	for(i=0;i<8;i++)
	{
		DQ = 0;
		DQ = dat&0x01;
		Delay80us();
		DQ = 1;
		dat >>= 1;
	}
	Delay80us();
}

//从DS18B20读取一个字节
unsigned char Read_DS18B20(void)
{
	unsigned char i;
	unsigned char dat;
  
	for(i=0;i<8;i++)
	{
		DQ = 0;
		dat >>= 1;
		DQ = 1;
		if(DQ)
		{
			dat |= 0x80;
		}	    
		Delay80us();
	}
	return dat;
}

//DS18B20设备初始化
void init_ds18b20(void)
{

  	DQ = 0;
  	Delay500us();
  	DQ = 1;
  	Delay500us();

}

long Read_Temp()
{
	long temp;
	uchar low,high;
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0x44);
	Delay500us();
	init_ds18b20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0xbe);
	low = Read_DS18B20();
	high = Read_DS18B20();
	temp = high<<8;
	temp |= low;
	return temp*625;
}

void Delay500us()		//@11.0592MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 6;
	j = 93;
	do
	{
		while (--j);
	} while (--i);
}

void Delay80us()		//@11.0592MHz
{
	unsigned char i, j;

	_nop_();
	i = 1;
	j = 217;
	do
	{
		while (--j);
	} while (--i);
}

