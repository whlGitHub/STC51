#include<STC15F2K60S2.H>
#include <intrins.h>
void Write_Ds1302(unsigned char temp);
void Write_Ds1302_Byte( unsigned char address,unsigned char dat );
void DS1302_Init(void);
void Ds1302_Get(void);
unsigned char Read_Ds1302_Byte( unsigned char address );
void delayMs(int ms);
void allInit();
char readKbd(); 
void ds(char com,char num);

unsigned char code ledStatus[]={0XFF,0XFE,0XFD,0XFB,0XF7,0XEF,0XDF,0XBF,0X7F,0X00};
unsigned char code dscom[]={0X00,0X01,0X02,0X04,0X08,0X10,0X20,0X40,0X80,0XFF};//λѡ
unsigned char code dsnum[]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X98,0X7F,0XBF,0X00,0XFF};//�ַ�

unsigned char Init_Time[]={50,59,23,13,10,2,20};//���ʱ��������
unsigned char timeArrary[7];