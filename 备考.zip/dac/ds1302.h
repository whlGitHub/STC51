#ifndef __DS1302_H
#define __DS1302_H



#endif
