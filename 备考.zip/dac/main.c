#include<STC15F2K60S2.H>
#include <intrins.h>

void Write_Ds1302(unsigned char temp);
void Write_Ds1302_Byte( unsigned char address,unsigned char dat );
void DS1302_Init(void);
void Ds1302_Get(void);
unsigned char Read_Ds1302_Byte( unsigned char address );
void delayMs(int ms);
void allInit();
char readKbd();
void ds(char com,char num);
unsigned char IIC_RecByte(void);
void IIC_SendByte(unsigned char byt);
bit IIC_WaitAck(void);
void IIC_SendAck(bit ackbit);
void IIC_Stop(void);
void IIC_Start(void);
void IIC_Delay(unsigned char i);
void operate_delay(unsigned char t);
void WriteEEPROM(unsigned char add, unsigned char val);
unsigned char ReadEEPROM(unsigned char add);
void WriteDAC(char dat);
unsigned char ReadADC(char channel);
void init_pcf8591(char channel);

unsigned char code ledStatus[]={0XFF,0XFE,0XFD,0XFB,0XF7,0XEF,0XDF,0XBF,0X7F,0X00};
unsigned char code dscom[]={0X00,0X01,0X02,0X04,0X08,0X10,0X20,0X40,0X80,0XFF};//位选
unsigned char code dsnum[]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X98,0X7F,0XBF,0X00,0XFF};//字符

unsigned char Init_Time[]={50,59,23,13,10,2,20};
unsigned char timeArray[7];

void main()
{

	unsigned char d1,d2,d3;
	unsigned char dat=0;
	allInit();
	
	while(1)
	{
		dat = ReadADC(0x01);//0x01为光敏电阻，0x03为电位器Rb2
		d1 = dat/100;
		d2 = dat%100/10;
		d3 = dat%10;
		ds(1,d1);
		ds(2,d2);
		ds(3,d3);
	}
	
}
void ds(char com,char num)
{
	P2=0XC0;
	P0=dscom[com];
	P2=0XE0;
	P0=dsnum[num];
	P2=0xFF;
	delayMs(1);
}
void allInit()
{
	P2=0XA0;
	P0=0X00;

	P2=0X80;
	P0=0XFF;

	P2=0XC0;
	P0=0XFF;
	P2=0XE0;
	P0=0XFF;
}



void delayMs(int ms)
{
	int i,j;
	for(i=ms;i>0;i--)
		for(j=845;j>0;j--);
}





sbit r1=P3^0;    //4行
sbit r2=P3^1;
sbit r3=P3^2;
sbit r4=P3^3;
                 //4列
sbit c1=P4^4;
sbit c2=P4^2;
sbit c3=P3^5;
sbit c4=P3^4;
char readKbd(void)
{
	unsigned char key_value = 0;

	r1=0;
	r2=r3=r4=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=1;
	else if(!c2) key_value=2;
	else if(!c3) key_value=3;
	else if(!c4) key_value=4;

    r2=0;
	r1=r3=r4=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=5;
	else if(!c2) key_value=6;
	else if(!c3) key_value=7;
	else if(!c4) key_value=8;

	r3=0;
	r2=r1=r4=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=9;
	else if(!c2) key_value=10;
	else if(!c3) key_value=11;
	else if(!c4) key_value=12;

	r4=0;
	r2=r3=r1=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=13;
	else if(!c2) key_value=14;
	else if(!c3) key_value=15;
	else if(!c4) key_value=16;
	
	return key_value;
}

#define DELAY_TIME 5

#define SlaveAddrW 0xA0
#define SlaveAddrR 0xA1

//总线引脚定义
sbit SDA = P2^1;  /* 数据线 */
sbit SCL = P2^0;  /* 时钟线 */

void IIC_Delay(unsigned char i)
{
    do{_nop_();}
    while(i--);        
}
//总线启动条件
void IIC_Start(void)
{
    SDA = 1;
    SCL = 1;
    IIC_Delay(DELAY_TIME);
    SDA = 0;
    IIC_Delay(DELAY_TIME);
    SCL = 0;	
}

//总线停止条件
void IIC_Stop(void)
{
    SDA = 0;
    SCL = 1;
    IIC_Delay(DELAY_TIME);
    SDA = 1;
    IIC_Delay(DELAY_TIME);
}

//发送应答
void IIC_SendAck(bit ackbit)
{
    SCL = 0;
    SDA = ackbit;  					// 0：应答，1：非应答
    IIC_Delay(DELAY_TIME);
    SCL = 1;
    IIC_Delay(DELAY_TIME);
    SCL = 0; 
    SDA = 1;
    IIC_Delay(DELAY_TIME);
}

//等待应答
bit IIC_WaitAck(void)
{
    bit ackbit;
	
    SCL  = 1;
    IIC_Delay(DELAY_TIME);
    ackbit = SDA;
    SCL = 0;
    IIC_Delay(DELAY_TIME);
    return ackbit;
}

//通过I2C总线发送数据
void IIC_SendByte(unsigned char byt)
{
    unsigned char i;

    for(i=0; i<8; i++)
    {
        SCL  = 0;
        IIC_Delay(DELAY_TIME);
        if(byt & 0x80) SDA  = 1;
        else SDA  = 0;
        IIC_Delay(DELAY_TIME);
        SCL = 1;
        byt <<= 1;
        IIC_Delay(DELAY_TIME);
    }
    SCL  = 0;  
}

//从I2C总线上接收数据
unsigned char IIC_RecByte(void)
{
    unsigned char i, da;
    for(i=0; i<8; i++)
    {   
    	SCL = 1;
	IIC_Delay(DELAY_TIME);
	da <<= 1;
	if(SDA) da |= 1;
	SCL = 0;
	IIC_Delay(DELAY_TIME);
    }
    return da;    
}

void operate_delay(unsigned char t)
{
    unsigned char i;

    while (t--)
    {
        for (i = 0; i < 112; i++)
            ;
    }
}

//向eeprom写入数据
void WriteEEPROM(unsigned char add, unsigned char val)
{
    IIC_Start();
    IIC_SendByte(0xa0);
    IIC_WaitAck();
    IIC_SendByte(add);
    IIC_WaitAck();
    IIC_SendByte(val);
    IIC_WaitAck();
    IIC_Stop();
    operate_delay(10);
}

//读取EEPROM中的数据
unsigned char ReadEEPROM(unsigned char add)
{
    unsigned char da;
    IIC_Start();
    IIC_SendByte(0xa0);
    IIC_WaitAck();
    IIC_SendByte(add);
    IIC_WaitAck();
    IIC_Start();
    IIC_SendByte(0xa1);
    IIC_WaitAck();
    da = IIC_RecByte();
    IIC_SendAck(1);
    IIC_Stop();
    return da;
}

unsigned char ReadADC(char channel) 
{
    unsigned char temp;
	init_pcf8591(channel);
	
    IIC_Start();
    IIC_SendByte(0x91);
    IIC_WaitAck();
    temp = IIC_RecByte();
    IIC_SendAck(1);
    IIC_Stop();

    return temp;
}

void WriteDAC(char dat)
{
//	unsigned char temp;
	
    IIC_Start();
    IIC_SendByte(0x90);
    IIC_WaitAck();
	IIC_SendByte(0x40);
	IIC_WaitAck();
    IIC_SendByte(dat);
	IIC_WaitAck();
    IIC_Stop();
}

void init_pcf8591(char channel)
{
    IIC_Start();
    IIC_SendByte(0x90);
    IIC_WaitAck();
    IIC_SendByte(channel); //ADC3
    IIC_WaitAck();
    IIC_Stop();
    operate_delay(10);
}