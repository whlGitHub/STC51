#include<STC15F2K60S2.H>
#include<intrins.h>
#include<stdio.h>
#define uchar unsigned char
#define uint unsigned int

void All_Init();
void Dis_Bit(uchar com,uchar singlenum);
void delay(uint t);
void Read_KBD();

void UartInit(void)	;
char putchar(char c);
void SendStr(unsigned char *str);

uchar key_value,read_buf;
const uchar code dscom[] = {0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0xff};
const uchar code dsnum[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};

void main()
{
	All_Init();
	UartInit();
	printf("start\r\n");
	while(1)
	{
		printf("test\r\n");
	}
	
}


void All_Init()
{
	P2 = 0xA0;
	P0 = 0x00;//�رշ�����

	P2 = 0x80;
	P0 = 0xFF;//�ر�led��

	P2 = 0xC0;
	P0 = 0xFF;
	P2 = 0xE0;
	P0 = 0xFF;
}

void Dis_Bit(uchar com,uchar singlenum)
{
	P2 = 0xC0;
	P0 = dscom[com];
	P2 = 0xE0;
	P0 = dsnum[singlenum];
	P2 = 0xFF;
	delay(5);
}

void delay(uint t)
{
	uint i;
	while(t--)
		for(i=0;i<845;i++);
}

sbit r1 = P3^0;
sbit r2 = P3^1;
sbit r3 = P3^2;
sbit r4 = P3^3;
sbit c1 = P4^4;
sbit c2 = P4^2;
sbit c3 = P3^5;
sbit c4 = P3^4;

void Read_KBD()
{
	uchar key_buf = 0;
	static key_state = 0;
	c1 = 0;
	c2 = c3 = c4 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 7;
	else if(!r2) key_buf = 6;
	else if(!r3) key_buf = 5;
	else if(!r4) key_buf = 4;

	c2 = 0;
	c1 = c3 = c4 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 11;
	else if(!r2) key_buf = 10;
	else if(!r3) key_buf = 9;
	else if(!r4) key_buf = 8;
	
	c3 = 0;
	c1 = c2 = c4 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 15;
	else if(!r2) key_buf = 14;
	else if(!r3) key_buf = 13;
	else if(!r4) key_buf = 12;

	c4 = 0;
	c1 = c2 = c3 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 19;
	else if(!r2) key_buf = 18;
	else if(!r3) key_buf = 17;
	else if(!r4) key_buf = 16;

	switch(key_state)
	{
		case 0:
			if(key_buf != 0)
			{
				read_buf = key_buf;
				key_state = 1;
			}
			break;
		case 1:
			if(read_buf == key_buf)
			{
				key_value = read_buf;
				key_state = 2;
			}
			break;
		case 2:
			if(key_buf == 0)
			{
				key_state = 0;
			}
			break;
		default:break;
	}
}


void UartInit(void)		//115200bps@11.0592MHz
{
	SCON = 0x50;		//8λ����,�ɱ䲨����
	AUXR |= 0x40;		//��ʱ��1ʱ��ΪFosc,��1T
	AUXR &= 0xFE;		//����1ѡ��ʱ��1Ϊ�����ʷ�����
	TMOD &= 0x0F;		//�趨��ʱ��1Ϊ16λ�Զ���װ��ʽ
	TL1 = 0xE8;		//�趨��ʱ��ֵ
	TH1 = 0xFF;		//�趨��ʱ��ֵ
	ET1 = 0;		//��ֹ��ʱ��1�ж�
	TR1 = 1;		//������ʱ��1
}


char putchar(char c)
{
    SBUF=c;
    while(TI!=1);   //�ȴ����ͳɹ�
    TI=0;           //��������жϱ�־
    return c;
}


void SendStr(unsigned char *str)
{
    unsigned char *p;

    p = str;
    while(*p != '\0')
    {
        SBUF = *p;
		while(TI == 0);
		TI = 0;
        p++;
    }
}