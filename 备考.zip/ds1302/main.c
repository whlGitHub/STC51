#include<STC15F2K60S2.H>
#include <intrins.h>

void Write_Ds1302(unsigned char temp);
void Write_Ds1302_Byte( unsigned char address,unsigned char dat );
void DS1302_Init(void);
void Ds1302_Get(void);
unsigned char Read_Ds1302_Byte( unsigned char address );
void delayMs(int ms);
void allInit();
char readKbd();
void ds(char com,char num);

unsigned char code ledStatus[]={0XFF,0XFE,0XFD,0XFB,0XF7,0XEF,0XDF,0XBF,0X7F,0X00};
unsigned char code dscom[]={0X00,0X01,0X02,0X04,0X08,0X10,0X20,0X40,0X80,0XFF};//位选
unsigned char code dsnum[]={0XC0,0XF9,0XA4,0XB0,0X99,0X92,0X82,0XF8,0X80,0X98,0X7F,0XBF,0X00,0XFF};//字符

unsigned char Init_Time[]={50,59,23,13,10,2,20};
unsigned char timeArray[7];

void main()
{
	unsigned char num = 0;
	unsigned char com = 0;
	unsigned char keyValue;
	unsigned char hh,hl,mh,ml,sh,sl;
	allInit();
	DS1302_Init();
	while(1)
	{
		DS1302_Get();
		hh=timeArray[2]/10;hl=timeArray[2]%10;
		mh=timeArray[1]/10;ml=timeArray[1]%10;
		sh=timeArray[0]/10;sl=timeArray[0]%10;
		ds(1,hh);
		ds(2,hl);
		ds(4,mh);
		ds(5,ml);
		ds(7,sh);
		ds(8,sl);
	}
	
}
void ds(char com,char num)
{
	P2=0XC0;
	P0=dscom[com];
	P2=0XE0;
	P0=dsnum[num];
	P2=0xFF;
	delayMs(1);
}
void allInit()
{
	P2=0XA0;
	P0=0X00;

	P2=0X80;
	P0=0XFF;

	P2=0XC0;
	P0=0XFF;
	P2=0XE0;
	P0=0XFF;
}



void delayMs(int ms)
{
	int i,j;
	for(i=ms;i>0;i--)
		for(j=845;j>0;j--);
}





sbit r1=P3^0;    //4行
sbit r2=P3^1;
sbit r3=P3^2;
sbit r4=P3^3;
                 //4列
sbit c1=P4^4;
sbit c2=P4^2;
sbit c3=P3^5;
sbit c4=P3^4;
char readKbd(void)
{
	unsigned char key_value = 0;

	r1=0;
	r2=r3=r4=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=1;
	else if(!c2) key_value=2;
	else if(!c3) key_value=3;
	else if(!c4) key_value=4;

    r2=0;
	r1=r3=r4=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=5;
	else if(!c2) key_value=6;
	else if(!c3) key_value=7;
	else if(!c4) key_value=8;

	r3=0;
	r2=r1=r4=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=9;
	else if(!c2) key_value=10;
	else if(!c3) key_value=11;
	else if(!c4) key_value=12;

	r4=0;
	r2=r3=r1=1;
	c1=c2=c3=c4=1;
	if(!c1) key_value=13;
	else if(!c2) key_value=14;
	else if(!c3) key_value=15;
	else if(!c4) key_value=16;
	
	return key_value;
}


sbit SCK=P1^7;		
sbit SDA=P2^3;		
sbit RST = P1^3;   // DS1302复位												

void Write_Ds1302(unsigned  char temp) 
{
	unsigned char i;
	for (i=0;i<8;i++)     	
	{ 
		SCK=0;
		SDA=temp&0x01;
		temp>>=1; 
		SCK=1;
	}
}   

void Write_Ds1302_Byte( unsigned char address,unsigned char dat )     
{
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
 	RST=1; 	_nop_();  
 	Write_Ds1302(address);	
	//Write_Ds1302(dat);
 	Write_Ds1302(((dat/10)<<4)|(dat%10));		
 	RST=0; 
}

unsigned char Read_Ds1302_Byte ( unsigned char address )
{
 	unsigned char i,temp=0x00,dat1,dat2;
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
 	RST=1;	_nop_();
 	Write_Ds1302(address);
 	for (i=0;i<8;i++) 	
 	{		
		SCK=0;
		temp>>=1;	
 		if(SDA)
 		temp|=0x80;	
 		SCK=1;
	} 
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
	SCK=1;	_nop_();
	SDA=0;	_nop_();
	SDA=1;	_nop_();
	dat1=temp/16;
	dat2=temp%16;
	temp=dat1*10+dat2;
	return (temp);			
}

void DS1302_Init(void)
{
	unsigned char i,add;
	add=0x80;
	Write_Ds1302_Byte(0x8e,0x00);
	for(i=0;i<7;i++)
	{
		Write_Ds1302_Byte(add,Init_Time[i]);
		add=add+2;
	}
	Write_Ds1302_Byte(0x8e,0x80);
}

void Ds1302_Get(void)
{
	unsigned char i,add;
	add=0x81;
	Write_Ds1302_Byte(0x8e,0x00);
	for(i=0;i<7;i++)
	{
		timeArray[i]=Read_Ds1302_Byte(add);
		add=add+2;
	}
	Write_Ds1302_Byte(0x8e,0x80);
}
