#include<STC15F2K60S2.H>
#include<intrins.h>
#include<stdio.h>
#define uchar unsigned char
#define uint unsigned int

void All_Init();
void Dis_Bit(uchar com,uchar singlenum);
void delay(uint t);
void Read_KBD();

void UartInit(void)	;
char putchar(char c);
void SendStr(unsigned char *str);

uchar key_value,read_buf;
const uchar code dscom[] = {0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0xff};
const uchar code dsnum[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};

void Write_DS18B20(unsigned char dat);
unsigned char Read_DS18B20(void);
bit init_ds18b20(void);
unsigned char ReadTemp(void);
float ReadTempFloat(void);

uchar Init_Time[7] = {50,59,23,16,10,5,20};
uchar timeArray[7] ;
void Write_Ds1302(unsigned  char temp);
void Write_Ds1302_Byte( unsigned char address,unsigned char dat );
unsigned char Read_Ds1302_Byte ( unsigned char address );
void DS1302_Init();
void DS1302_Get();

void IIC_Delay(unsigned char i);
void IIC_Start(void);
void IIC_Stop(void);
void IIC_SendAck(bit ackbit);
bit IIC_WaitAck(void);
void IIC_SendByte(unsigned char byt);
unsigned char IIC_RecByte(void);
unsigned char Read_EEPROM(add);
void Write_EEPROM(uchar add,uchar val);

void Write_ADC(char val);
uchar Read_ADC(uchar channel);
void PCF8591_Init(uchar channel);

uint tt,freq;
void Freq_Timer0(void);
void Freq_Timer1(void);

uint PWM_NUM;
void PWM_Init();

unsigned int Check_Distance();
void send_wave(void) ;

void main()
{
	All_Init();
	PWM_Init();
	EA = 1;
	ET0 = 1;
	while(1)
	{	

	}
	
}


void All_Init()
{
	P2 = 0xA0;
	P0 = 0x00;//�رշ�����

	P2 = 0x80;
	P0 = 0xFF;//�ر�led��

	P2 = 0xC0;
	P0 = 0xFF;
	P2 = 0xE0;
	P0 = 0xFF;
}

void Dis_Bit(uchar com,uchar singlenum)
{
	P2 = 0xC0;
	P0 = dscom[com];
	P2 = 0xE0;
	P0 = dsnum[singlenum];
	P2 = 0xFF;
	delay(5);
}

void delay(uint t)
{
	uint i;
	while(t--)
		for(i=0;i<845;i++);
}

sbit r1 = P3^0;
sbit r2 = P3^1;
sbit r3 = P3^2;
sbit r4 = P3^3;
sbit c1 = P4^4;
sbit c2 = P4^2;
sbit c3 = P3^5;
sbit c4 = P3^4;

void Read_KBD()
{
	uchar key_buf = 0;
	static key_state = 0;
	c1 = 0;
	c2 = c3 = c4 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 7;
	else if(!r2) key_buf = 6;
	else if(!r3) key_buf = 5;
	else if(!r4) key_buf = 4;

	c2 = 0;
	c1 = c3 = c4 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 11;
	else if(!r2) key_buf = 10;
	else if(!r3) key_buf = 9;
	else if(!r4) key_buf = 8;
	
	c3 = 0;
	c1 = c2 = c4 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 15;
	else if(!r2) key_buf = 14;
	else if(!r3) key_buf = 13;
	else if(!r4) key_buf = 12;

	c4 = 0;
	c1 = c2 = c3 = 1;
	r1 = r2 = r3 = r4 = 1;
	if(!r1) key_buf = 19;
	else if(!r2) key_buf = 18;
	else if(!r3) key_buf = 17;
	else if(!r4) key_buf = 16;

	switch(key_state)
	{
		case 0:
			if(key_buf != 0)
			{
				read_buf = key_buf;
				key_state = 1;
			}
			break;
		case 1:
			if(read_buf == key_buf)
			{
				key_value = read_buf;
				key_state = 2;
			}
			break;
		case 2:
			if(key_buf == 0)
			{
				key_state = 0;
			}
			break;
		default:break;
	}
}


void UartInit(void)		//115200bps@11.0592MHz
{
	SCON = 0x50;		//8λ����,�ɱ䲨����
	AUXR |= 0x01;		//����1ѡ��ʱ��2Ϊ�����ʷ�����
	AUXR |= 0x04;		//��ʱ��2ʱ��ΪFosc,��1T
	T2L = 0xE8;		//�趨��ʱ��ֵ
	T2H = 0xFF;		//�趨��ʱ��ֵ
	AUXR |= 0x10;		//������ʱ��2
}


char putchar(char c)
{
    SBUF=c;
    while(TI!=1);   //�ȴ����ͳɹ�
    TI=0;           //��������жϱ�־
    return c;
}


void SendStr(unsigned char *str)
{
    unsigned char *p;

    p = str;
    while(*p != '\0')
    {
        SBUF = *p;
		while(TI == 0);
		TI = 0;
        p++;
    }
}
sbit DQ = P1^4;

//��������ʱ����

void Delay_OneWire(unsigned int t)  //STC12C5260S2
{
	unsigned char i;
	while(t--){
		for(i=0;i<12;i++);
	}
}

//ͨ����������DS18B20дһ���ֽ�
void Write_DS18B20(unsigned char dat)
{

	unsigned char i;
	for(i=0;i<8;i++)
	{
		DQ = 0;
		DQ = dat&0x01;
		Delay_OneWire(5);
		DQ = 1;
		dat >>= 1;
	}
	Delay_OneWire(5);
}

//��DS18B20��ȡһ���ֽ�
unsigned char Read_DS18B20(void)
{
	unsigned char i;
	unsigned char dat;
  
	for(i=0;i<8;i++)
	{
		DQ = 0;
		dat >>= 1;
		DQ = 1;
		if(DQ)
		{
			dat |= 0x80;
		}	    
		Delay_OneWire(5);
	}
	return dat;
}

//DS18B20��ʼ��
bit init_ds18b20(void)
{
  	bit initflag = 0;
  	
  	DQ = 1;
  	Delay_OneWire(12);
  	DQ = 0;
  	Delay_OneWire(80); // ��ʱ����480us
  	DQ = 1;
  	Delay_OneWire(10);  // 14
  	initflag = DQ;     // initflag����1��ʼ��ʧ��
  	Delay_OneWire(5);
  
  	return initflag;
}

//DS18B20�¶Ȳɼ���������
unsigned char ReadTemp(void)
{
	unsigned char low,high;
	char temp;

	init_ds18b20();
	Write_DS18B20(0xCC);
	Write_DS18B20(0x44); //�����¶�ת��
	Delay_OneWire(200);

	init_ds18b20();
	Write_DS18B20(0xCC);
	Write_DS18B20(0xBE); //��ȡ�Ĵ���

	low = Read_DS18B20(); //���ֽ�
	high = Read_DS18B20(); //���ֽ�
	/** ����Ϊ1���϶� */  
	temp = high<<4;
	temp |= (low>>4);
	return temp;
}

//DS18B20�¶Ȳɼ����򣺸�����
float ReadTempFloat(void)
{
    unsigned int temp;
	float temperature;
    unsigned char low,high;
  
  	init_ds18b20();
  	Write_DS18B20(0xCC);
  	Write_DS18B20(0x44); //�����¶�ת��
  	Delay_OneWire(200);

  	init_ds18b20();
  	Write_DS18B20(0xCC);
  	Write_DS18B20(0xBE); //��ȡ�Ĵ���

  	low = Read_DS18B20(); //���ֽ�
  	high = Read_DS18B20(); //���ֽ�
/** ����Ϊ0.0625���϶� */  
	temp = (high&0x0f);
	temp <<= 8;
	temp |= low;
	temperature = temp*0.0625;
  	return temperature;
}


/*
sbit SCK=P1^7;		
sbit SDA=P2^3;		
sbit RST = P1^3;   // DS1302��λ												

void Write_Ds1302(unsigned  char temp) 
{
	unsigned char i;
	for (i=0;i<8;i++)     	
	{ 
		SCK=0;
		SDA=temp&0x01;
		temp>>=1; 
		SCK=1;
	}
}   

void Write_Ds1302_Byte( unsigned char address,unsigned char dat )     
{
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
 	RST=1; 	_nop_();  
 	Write_Ds1302(address);	
 	Write_Ds1302(((dat/10)<<4)|(dat%10));		
 	RST=0; 
}

unsigned char Read_Ds1302_Byte ( unsigned char address )
{
 	unsigned char i,temp=0x00,dat1,dat2;
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
 	RST=1;	_nop_();
 	Write_Ds1302(address);
 	for (i=0;i<8;i++) 	
 	{		
		SCK=0;
		temp>>=1;	
 		if(SDA)
 		temp|=0x80;	
 		SCK=1;
	} 
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
	SCK=1;	_nop_();
	SDA=0;	_nop_();
	SDA=1;	_nop_();
	dat1 = temp/16;
	dat2 = temp%16;
	temp = dat1*10+dat2;
	return (temp);			
}

void DS1302_Init()
{
	unsigned char i,add;
	add = 0x80;
	Write_Ds1302_Byte(0x8e,0x00);
	for(i = 0;i < 7;i++)
	{
		Write_Ds1302_Byte(add,Init_Time[i]);
		add = add+2;
	}
	Write_Ds1302_Byte(0x8e,0x80);
}

void DS1302_Get()
{
	unsigned char i,add;
	add = 0x81;
	Write_Ds1302_Byte(0x8e,0x00);
	for(i = 0;i<7;i++)
	{
		timeArray[i] = Read_Ds1302_Byte(add);
		add = add+2;
	}
	Write_Ds1302_Byte(0x8e,0x80);
}

*/

#define DELAY_TIME 5

#define SlaveAddrW 0xA0
#define SlaveAddrR 0xA1

//�������Ŷ���
sbit SDA = P2^1;  /* ������ */
sbit SCL = P2^0;  /* ʱ���� */

void IIC_Delay(unsigned char i)
{
    do{_nop_();}
    while(i--);        
}
//������������
void IIC_Start(void)
{
    SDA = 1;
    SCL = 1;
    IIC_Delay(DELAY_TIME);
    SDA = 0;
    IIC_Delay(DELAY_TIME);
    SCL = 0;	
}

//����ֹͣ����
void IIC_Stop(void)
{
    SDA = 0;
    SCL = 1;
    IIC_Delay(DELAY_TIME);
    SDA = 1;
    IIC_Delay(DELAY_TIME);
}

//����Ӧ��
void IIC_SendAck(bit ackbit)
{
    SCL = 0;
    SDA = ackbit;  					// 0��Ӧ��1����Ӧ��
    IIC_Delay(DELAY_TIME);
    SCL = 1;
    IIC_Delay(DELAY_TIME);
    SCL = 0; 
    SDA = 1;
    IIC_Delay(DELAY_TIME);
}

//�ȴ�Ӧ��
bit IIC_WaitAck(void)
{
    bit ackbit;
	
    SCL  = 1;
    IIC_Delay(DELAY_TIME);
    ackbit = SDA;
    SCL = 0;
    IIC_Delay(DELAY_TIME);
    return ackbit;
}

//ͨ��I2C���߷�������
void IIC_SendByte(unsigned char byt)
{
    unsigned char i;

    for(i=0; i<8; i++)
    {
        SCL  = 0;
        IIC_Delay(DELAY_TIME);
        if(byt & 0x80) SDA  = 1;
        else SDA  = 0;
        IIC_Delay(DELAY_TIME);
        SCL = 1;
        byt <<= 1;
        IIC_Delay(DELAY_TIME);
    }
    SCL  = 0;  
}

//��I2C�����Ͻ�������
unsigned char IIC_RecByte(void)
{
    unsigned char i, da;
    for(i=0; i<8; i++)
    {   
    	SCL = 1;
	IIC_Delay(DELAY_TIME);
	da <<= 1;
	if(SDA) da |= 1;
	SCL = 0;
	IIC_Delay(DELAY_TIME);
    }
    return da;    
}

void Write_EEPROM(uchar add,uchar val)
{
	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(add);
	IIC_WaitAck();
	IIC_SendByte(val);
	IIC_WaitAck();
	IIC_Stop();
	delay(10);
}

unsigned char Read_EEPROM(uchar add)
{
	uchar dat;
	IIC_Start();
	IIC_SendByte(0xa0);
	IIC_WaitAck();
	IIC_SendByte(add);
	IIC_WaitAck();
	IIC_Start();
	IIC_SendByte(0xa1);
	IIC_WaitAck();
	dat = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
	return dat;
}

void PCF8591_Init(uchar channel)
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(channel);
	IIC_WaitAck();
	IIC_Stop();
	delay(1);
}

uchar Read_ADC(char channel)
{
	uchar temp;
	PCF8591_Init(channel);
	
	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	temp = IIC_RecByte();
	IIC_SendAck(1);
	IIC_Stop();
	return temp;
}

void Write_ADC(char val)
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(0x40);
	IIC_WaitAck();
	IIC_SendByte(val);
	IIC_WaitAck();
	IIC_Stop();
}

void Freq_Handler()        interrupt 3
{
	tt++;
	if(tt==1000)
	{
			TR0=0;        
			tt=0;
			freq=TH0*256+TL0;
			TH0=0;
			TL0=0;
			TR0=1;
	}        
}

void Freq_Timer1(void)		//1����@11.0592MHz
{
	AUXR |= 0x40;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;		//���ö�ʱ��ģʽ
	TL1 = 0xCD;		//���ö�ʱ��ֵ
	TH1 = 0xD4;		//���ö�ʱ��ֵ
	TF1 = 0;		//���TF1��־
	TR1 = 1;		//��ʱ��1��ʼ��ʱ
}

void Freq_Timer0(void)        
{
	AUXR &= 0x80;                //��ʱ��ʱ��1Tģʽ
	TMOD |= 0x05;                //���ö�ʱ��Ϊ����ģʽ
	TL0 = 0x00;                    //���ö�ʱ��ֵ
	TH0 = 0x00;                    //���ö�ʱ��ֵ
	TF0 = 0;                    //���TF0��־
	TR0 = 1;                    //��ʱ��0��ʼ��ʱ
}

void PWM_Init(void)
{
	AUXR |= 0x80;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TL0 = 0xAE;		//���ö�ʱ��ֵ
	TH0 = 0xFB;		//���ö�ʱ��ֵ
	TF0 = 0;		//���TF0��־
	TR0 = 1;		//��ʱ��0��ʼ��ʱ
}

void PWM_Output(void)	interrupt 1
{
	tt++;
	if(tt == PWM_NUM)
	{
		Dis_Bit(1,1);
	}
	else if(tt == 100)
	{
		Dis_Bit(1,10);
		tt = 0;
		PWM_NUM++;
		if(PWM_NUM == 100)
		{
			PWM_NUM = 0;
		}
	}
}

#define somenops {_nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_();}

sbit TX = P1^0; //��������
sbit RX = P1^1; //��������

//TX ���ŷ��� 40KHz �����ź���������������̽ͷ

void send_wave(void) 
{
	unsigned char i = 8; //���� 8 ������
	
	do {
		TX = 1;
		somenops;somenops;somenops;somenops;somenops;  
		somenops;somenops;somenops;somenops;somenops;
		TX = 0;
		somenops;somenops;somenops;somenops;somenops;  
		somenops;somenops;somenops;somenops;somenops;
	} while(i--);
}

unsigned int Check_Distance()
{
	unsigned int distance,t;

    TMOD &= 0xF0;  //���ö�ʱ������ģʽ
    TH0 = 0;
    TL0 = 0;  
  
    EA = 1;
    ET0 = 0;  //�򿪶�ʱ��0�ж�
    //TR0 = 1;  //������ʱ��   

	send_wave();  //���ͷ����ź�
	TR0= 1;  //������ʱ
	while((RX == 1) && (TF0 == 0));  //�ȴ��յ�����
		 TR0 = 0;  //�رռ�ʱ

	//�������
	if(TF0 == 1)
	{
		TF0= 0;
		distance = 999;  //�޷���
	}
	else
	{
		/**  ����ʱ��  */
		t = (TH0<<8)|TL0;
		distance = (unsigned int)(t*0.017);  //�������				
		//distance = (unsigned int)(t*17/1000);  //�������				
	}
	TH0 = 0;
	TL0 = 0;
	return distance;
}