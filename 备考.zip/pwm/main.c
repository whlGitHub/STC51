#include<STC15F2K60S2.H>
#include <intrins.h>
#define uchar unsigned char
#define uint unsigned int
void delayMs(int ms);
void allInit();
char readKbd();
void ds(char com,char num);
void Timer0Init(void);
void smg_xianshi(uchar yi,er,san,si,wu,liu,qi,ba);

unsigned char code ledStatus[]={0XFF,0XFE,0XFD,0XFB,0XF7,0XEF,0XDF,0XBF,0X7F,0X00};
unsigned char code dscom[]={0X00,0X01,0X02,0X04,0X08,0X10,0X20,0X40,0X80,0XFF};//位选
unsigned char code dsnum[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf,0xff};//字符
uint tt;
uchar pwm_num;
void main()
{

	unsigned char d1,d2,d3,d4,d5;
	allInit();
	Timer0Init();
	EA = 1;
	ET0 = 1;
	while(1)
	{
		//smg_xianshi(d1,d2,d3,d4,d5,11,11,11);
	}
	
}
void Timer0Init(void)		//100微秒@11.0592MHz pwm频率100hz 周期0.01s 10ms 10000us=100us*100
{
	AUXR |= 0x80;		//定时器时钟1T模式
	TMOD &= 0xF0;		//设置定时器模式
	TL0 = 0xAE;		//设置定时初值
	TH0 = 0xFB;		//设置定时初值
	TF0 = 0;		//清除TF0标志
	TR0 = 1;		//定时器0开始计时
}

void Timer0()	interrupt 1
{
	tt++;
	if(tt==pwm_num)
	{
	  ds(1,1);
	}
	else if(tt==100)
	{
		ds(1,0);
		tt=0;
		pwm_num++;
		if(pwm_num==100)
			pwm_num = 10;
	}
}
void ds(char com,char num)
{
	P2=0XC0;
	P0=dscom[com];
	P2=0XE0;
	P0=dsnum[num];
	P2=0xFF;
	delayMs(5);
}

void allInit()
{
	P2=0XA0;
	P0=0X00;

	P2=0X80;
	P0=0XFF;

	P2=0XC0;
	P0=0XFF;
	P2=0XE0;
	P0=0XFF;
}

void delayMs(int ms)
{
	int i,j;
	for(i=ms;i>0;i--)
		for(j=845;j>0;j--);
}

void  smg_xianshi(uchar yi,er,san,si,wu,liu,qi,ba)
{
	P2=0xc0;
	P0=0x01;
	P2=0xe0;
	P0=dsnum[yi];
	delayMs(1);

	P2=0xc0;
	P0=0x02;
	P2=0xe0;
	P0=dsnum[er];
	delayMs(1);

	P2=0xc0;
	P0=0x04;
	P2=0xe0;
	P0=dsnum[san];
	delayMs(1);

	P2=0xc0;
	P0=0x08;
	P2=0xe0;
	P0=dsnum[si];
	delayMs(1);

	P2=0xc0;
	P0=0x10;
	P2=0xe0;
	P0=dsnum[wu];
	delayMs(1);        

	P2=0xc0;
	P0=0x20;
	P2=0xe0;
	P0=dsnum[liu];
	delayMs(1);

	P2=0xc0;
	P0=0x40;
	P2=0xe0;
	P0=dsnum[qi];
	delayMs(1);

	P2=0xc0;
	P0=0x80;
	P2=0xe0;
	P0=dsnum[ba];
	delayMs(1);   
}     
